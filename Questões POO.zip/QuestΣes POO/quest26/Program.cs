﻿using System;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

public class Usuario
{
    private string _hashSenha;

    public Usuario(string senha)
    {
        if (string.IsNullOrWhiteSpace(senha))
            throw new ArgumentException("A senha não pode ser vazia ou conter espaços em branco.");

        if (!ValidarComplexidadeSenha(senha))
            throw new ArgumentException("Senha inválida. Ela deve ter pelo menos 8 caracteres, contendo letras maiúsculas, minúsculas, números e caracteres especiais.");

        _hashSenha = GerarHashSenha(senha);
    }

    private string GerarHashSenha(string senha)
    {
        using (SHA256 sha256 = SHA256.Create())
        {
            byte[] hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(senha));
            return Convert.ToBase64String(hashBytes);
        }
    }

    public bool Autenticar(string senhaInformada)
    {
        string hashSenhaInformada = GerarHashSenha(senhaInformada);
        return _hashSenha == hashSenhaInformada;
    }

    private bool ValidarComplexidadeSenha(string senha)
    {
        var regex = new Regex(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$");
        return regex.IsMatch(senha);
    }

    public void AlterarSenha(string senhaAtual, string novaSenha)
    {
        if (!Autenticar(senhaAtual))
            throw new UnauthorizedAccessException("Senha atual incorreta.");

        if (string.IsNullOrWhiteSpace(novaSenha))
            throw new ArgumentException("A nova senha não pode ser vazia ou conter espaços em branco.");

        if (!ValidarComplexidadeSenha(novaSenha))
            throw new ArgumentException("Nova senha inválida. Ela deve ter pelo menos 8 caracteres, contendo letras maiúsculas, minúsculas, números e caracteres especiais.");

        _hashSenha = GerarHashSenha(novaSenha);
    }
}

class Program
{
    static void Main(string[] args)
    {
        try
        {
     
            Console.WriteLine("Criação de usuário:");
            Console.Write("Digite uma senha para o usuário (deve ter pelo menos 8 caracteres, incluindo maiúsculas, minúsculas, números e caracteres especiais): ");
            string senhaInicial = Console.ReadLine();
            Usuario usuario = new Usuario(senhaInicial);

            Console.WriteLine("Usuário criado com sucesso!\n");

            Console.Write("Digite a senha para autenticar: ");
            string senhaAutenticacao = Console.ReadLine();

            if (usuario.Autenticar(senhaAutenticacao))
            {
                Console.WriteLine("Autenticado com sucesso!");
            }
            else
            {
                Console.WriteLine("Falha na autenticação.");
            }

            Console.WriteLine("\nAlterando a senha:");
            Console.Write("Digite a senha atual para alteração: ");
            string senhaAtual = Console.ReadLine();

            Console.Write("Digite a nova senha: ");
            string novaSenha = Console.ReadLine();

            try
            {
                usuario.AlterarSenha(senhaAtual, novaSenha);
                Console.WriteLine("Senha alterada com sucesso!");

                Console.Write("Digite a nova senha para autenticação: ");
                string novaSenhaAutenticacao = Console.ReadLine();

                if (usuario.Autenticar(novaSenhaAutenticacao))
                {
                    Console.WriteLine("Autenticado com sucesso com a nova senha!");
                }
                else
                {
                    Console.WriteLine("Falha na autenticação com a nova senha.");
                }
            }
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine($"Erro: {ex.Message}");
            }

        }
        catch (Exception ex)
        {
            Console.WriteLine($"Erro: {ex.Message}");
        }
    }
}

