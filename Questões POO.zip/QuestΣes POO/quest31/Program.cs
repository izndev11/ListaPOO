﻿using System;

public class Animal
{
    public virtual void FazerSom() 
    { 
        Console.WriteLine("Som genérico de animal.");
    }
}

public class Cachorro : Animal
{

    public override void FazerSom()
    {
        Console.WriteLine("Latir");
    }
}

public class Program31
{
    public static void Main(string[] args)
    {
        Animal meuAnimal = new Animal();
        meuAnimal.FazerSom();

        Cachorro meuCachorro = new Cachorro();
        meuCachorro.FazerSom();
    }
}