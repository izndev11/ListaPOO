﻿using System;

public class BibliotecaItem
{
    public string Titulo { get; set; }

    public BibliotecaItem(string titulo)
    {
        Titulo = titulo;
    }

    public virtual string ObterTituloCompleto()
    {
        return Titulo;
    }
}

public class Livro : BibliotecaItem
{
    public string Autor { get; set; }

    public Livro(string titulo, string autor) : base(titulo)
    {
        Autor = autor;
    }

    public override string ObterTituloCompleto()
    {
        return $"Livro: '{Titulo}' por {Autor}";
    }
}

public class Revista : BibliotecaItem
{
    public string Edicao { get; set; }

    public Revista(string titulo, string edicao) : base(titulo)
    {
        Edicao = edicao;
    }

    public override string ObterTituloCompleto()
    {
        return $"Revista: '{Titulo}' (Edição {Edicao})";
    }
}

public class Program40
{
    public static void Main(string[] args)
    {
        BibliotecaItem itemGenerico = new BibliotecaItem("Manual");
        Console.WriteLine(itemGenerico.ObterTituloCompleto());

        Livro meuLivro = new Livro("O Tesouro de Olinda", "Rogério Andrade Barbosa");
        Console.WriteLine(meuLivro.ObterTituloCompleto());

        Revista minhaRevista = new Revista("Super Interessante", "Março 2024");
        Console.WriteLine(minhaRevista.ObterTituloCompleto());
    }
}