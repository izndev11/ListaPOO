﻿using System;

public abstract class Forma
{
    public abstract double CalcularArea();

    public virtual void ExibirTipo()
    {
        Console.WriteLine("Esta é uma forma geométrica.");
    }
}

public class Triangulo : Forma
{
    public double Base { get; set; }
    public double Altura { get; set; }

    public Triangulo(double @base, double altura)
    {
        Base = @base;
        Altura = altura;
    }

    public override double CalcularArea()
    {
        return (Base * Altura) / 2.0;
    }

    public override void ExibirTipo()
    {
        Console.WriteLine("Esta é um Triângulo.");
    }
}

public class Retangulo : Forma
{
    public double Largura { get; set; }
    public double Altura { get; set; }

    public Retangulo(double largura, double altura)
    {
        Largura = largura;
        Altura = altura;
    }

    public override double CalcularArea()
    {
        return Largura * Altura;
    }

    public override void ExibirTipo()
    {
        Console.WriteLine("Este é um Retângulo.");
    }
}

public class Program51
{
    public static void Main(string[] args)
    {

        List<Forma> formas = new List<Forma>();
        formas.Add(new Triangulo(10, 5));
        formas.Add(new Retangulo(7, 4));
        formas.Add(new Triangulo(6, 8));

        Console.WriteLine("Calculando áreas das formas:");
        foreach (Forma f in formas)
        {
            f.ExibirTipo();
            Console.WriteLine($"Área: {f.CalcularArea():F2}");
            Console.WriteLine("---");
        }
        
    }
}