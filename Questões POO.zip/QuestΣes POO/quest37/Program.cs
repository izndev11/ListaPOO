﻿using System;

public class Produto
{
    public string Nome { get; set; }
    public decimal Preco { get; set; }

    public Produto(string nome, decimal preco)
    {
        Nome = nome;
        Preco = preco;
    }

    public virtual void ExibirDetalhes()
    {
        Console.WriteLine($"Produto: {Nome}, Preço: {Preco:C}");
    }
}

public class ProdutoDigital : Produto
{
    public double TamanhoArquivoMB { get; set; }

    public ProdutoDigital(string nome, decimal preco, double tamanhoArquivoMB) : base(nome, preco)
    {
        TamanhoArquivoMB = tamanhoArquivoMB;
    }

    public void Baixar()
    {
        Console.WriteLine($"Baixando produto digital '{Nome}' ({TamanhoArquivoMB} MB)...");
      
    }

    public override void ExibirDetalhes()
    {
        base.ExibirDetalhes();
        Console.WriteLine($"Tamanho do Arquivo: {TamanhoArquivoMB} MB");
    }
}
public class Program37
{
    public static void Main(string[] args)
    {
        Produto fisico = new Produto("Livro", 50.00m);
        fisico.ExibirDetalhes();

        ProdutoDigital ebook = new ProdutoDigital("Guia C#", 35.50m, 10.5);
        ebook.ExibirDetalhes();
        ebook.Baixar();
    }
}