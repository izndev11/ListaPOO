﻿using System;
public abstract class Simulador
{
    public abstract void Iniciar();
    public abstract void Executar();
    public abstract void Finalizar();
}

public class SimuladorJogo : Simulador
{
    public override void Iniciar()
    {
        Console.WriteLine("Iniciando simulador de jogo...");
    }

    public override void Executar()
    {
        Console.WriteLine("Executando jogo...");
    }

    public override void Finalizar()
    {
        Console.WriteLine("Finalizando jogo. Exibindo resultados.");
    }
}

public class SimuladorTreinamento : Simulador
{
    public override void Iniciar()
    {
        Console.WriteLine("Iniciando simulador de treinamento...");
    }

    public override void Executar()
    {
        Console.WriteLine("Executando treinamento...");
    }

    public override void Finalizar()
    {
        Console.WriteLine("Finalizando treinamento. Exibindo desempenho.");
    }

}

public abstract class Notificador
{
    public abstract void Enviar(string mensagem);
}

public class EmailNotificador : Notificador
{
    public override void Enviar(string mensagem)
    {
        Console.WriteLine($"Enviando email: {mensagem}");
    }
}

public class SMSNotificador : Notificador
{
    public override void Enviar(string mensagem)
    {
        Console.WriteLine($"Enviando SMS: {mensagem}");
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        Notificador emailNotifier = new EmailNotificador();
        Notificador smsNotifier = new SMSNotificador();

        emailNotifier.Enviar("Mensagem de teste por email!");
        smsNotifier.Enviar("Mensagem de teste por SMS!");

        Console.WriteLine("\n-----------------\n");

        Simulador jogoSim = new SimuladorJogo();
        Simulador treinoSim = new SimuladorTreinamento();

        Console.WriteLine("--- Simulador de Jogo ---");
        jogoSim.Iniciar();
        jogoSim.Executar();
        jogoSim.Finalizar();

        Console.WriteLine("\n--- Simulador de Treinamento ---");
        treinoSim.Iniciar();
        treinoSim.Executar();
        treinoSim.Finalizar();
    }
}