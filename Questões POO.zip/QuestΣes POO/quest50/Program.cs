﻿using System;
using System.Collections.Generic;

public interface iTouch
{
    void TocarNaTela();
}

public class Dispositivo
{
    public virtual void Ligar()
    {
        Console.WriteLine("Dispositivo ligando...");
    }
}

public class Smartphone : Dispositivo, iTouch
{
    public override void Ligar()
    {
        Console.WriteLine("Smartphone ligando...");
        base.Ligar();
    }

    public void TocarNaTela()
    {
        Console.WriteLine("Smartphone: Toque na tela para interagir.");
    }
}

public class Tablet : Dispositivo, iTouch
{
    public override void Ligar()
    {
        Console.WriteLine("Tablet ligando...");
        base.Ligar();
    }

    public void TocarNaTela()
    {
        Console.WriteLine("Tablet: Toque na tela para interagir.");
    }
}

public class Program50
{
    public static void Main(string[] args)
    {

        List<Dispositivo> dispositivos = new List<Dispositivo>();
        dispositivos.Add(new Smartphone());
        dispositivos.Add(new Tablet());
        dispositivos.Add(new Dispositivo());

        Console.WriteLine("Ligando dispositivos:");
        foreach (Dispositivo d in dispositivos)
        {
            d.Ligar();
        }

        Console.WriteLine("\nInteragindo com dispositivos touch:");
        foreach (Dispositivo d in dispositivos)
        {
            if (d is iTouch touchDevice)
            {
                touchDevice.TocarNaTela();
            }
        }
        
    }
}