﻿using System;

public class Livro
{
    public string Titulo { get; set; } = string.Empty;
    public string Autor { get; set; } = string.Empty;

    public void ExibirInfo()
    {
        Console.WriteLine($"Titulo: {Titulo}");
        Console.WriteLine($"Autor: {Autor}");
    }

}

class Program
{
    static void Main( string[] args)
    {
        Livro livro1 = new Livro();

        livro1.Titulo = "1984";
        livro1.Autor = "George Orwell";

        Console.WriteLine("--Info dos Livros--");
        livro1.ExibirInfo();
    }
    
}

