﻿using System;

public abstract class Notificador
{
    public abstract void Enviar(string mensagem);
}

public class EmailNotificador : Notificador
{
    public override void Enviar(string mensagem)
    {
        Console.WriteLine($"Enviando email: {mensagem}");
    }
}

public class SMSNotificador : Notificador
{
    public override void Enviar(string mensagem)
    {
        Console.WriteLine($"Enviando SMS: {mensagem}");
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        Notificador emailNotifier = new EmailNotificador();
        Notificador smsNotifier = new SMSNotificador();

        emailNotifier.Enviar("Este é um teste de email.");
        smsNotifier.Enviar("Este é um teste de SMS.");
    }
}