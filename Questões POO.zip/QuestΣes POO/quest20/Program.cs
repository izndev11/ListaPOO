﻿using System;

public class Jogo
{
    public string Nome { get; set; } = string.Empty;
    public string Plataforma { get; set; } = string.Empty;

    public Jogo(string nome, string plataforma)
    {
        Nome = nome;
        Plataforma = plataforma;
    }

    public void Jogar()
    {
        Console.WriteLine($"Iniciando {Nome} no {Plataforma}.");
    }

}

class Program
{
    static void Main(string[] args)
    {
        Jogo jogo = new Jogo("The Last of Us Part 2", "PC");

        jogo.Jogar();

    }
}