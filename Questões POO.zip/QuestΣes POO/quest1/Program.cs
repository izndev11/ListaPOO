﻿using System;

public class Pessoa
{

    static void Main(string[] args)
    {

        Pessoa pessoa = new Pessoa();

    }


}

