﻿using System;

public class FormaGeometrica
{

    public virtual double CalcularPerimetro()
    {
        return 0.0;
    }
}

public class Retangulo : FormaGeometrica
{
    public double Largura { get; set; }
    public double Altura { get; set; }

    public Retangulo(double largura, double altura)
    {
        Largura = largura;
        Altura = altura;
    }

    public override double CalcularPerimetro()
    {
        return 2 * (Largura + Altura);
    }
}

public class Circulo : FormaGeometrica
{
    public double Raio { get; set; }
    public const double PI = Math.PI;

    public Circulo(double raio)
    {
        Raio = raio;
    }

    public override double CalcularPerimetro()
    {
        return 2 * PI * Raio;
    }
}

public class Program43
{
    public static void Main(string[] args)
    {
       
        List<FormaGeometrica> formas = new List<FormaGeometrica>();

        formas.Add(new Retangulo(5, 10));
        formas.Add(new Circulo(7));
        formas.Add(new Retangulo(3.5, 6.2));

        Console.WriteLine("Calculando perímetros:");
        foreach (FormaGeometrica forma in formas)
        {
         
            Console.WriteLine($"Perímetro: {forma.CalcularPerimetro():F2}");
        }
        
    }
}