﻿using System;

public class Ponto
{
    public double X { get; set; }
    public double Y { get; set; }

    public Ponto(double x, double y)
    {
        X = x;
        Y = y;
    }

    public double DistanciaOrigem()
    {

        double distancia = Math.Sqrt(Math.Pow(X, 2) + Math.Pow(Y, 2));

        return distancia;
    }
}

class Program
{
    static void Main(string[] args)
    {
        Ponto meuPonto = new Ponto(3, 4);

        double distancia = meuPonto.DistanciaOrigem();

        Console.WriteLine($"As coordenadas do ponto são: ({meuPonto.X}, {meuPonto.Y})");
        Console.WriteLine($"A distância do ponto à origem (0,0) é: {distancia}");
    }
}


