﻿using System;
using System.Collections.Generic;

public class Biblioteca
{
    public List<string> Livros { get; private set; }

    public Biblioteca()
    {
        Livros = new List<string>();
    }

    public void AdicionarLivro(string titulo)
    {
        Livros.Add(titulo);
        Console.WriteLine($"Livro '{titulo}' adicionado à biblioteca.");
    }
}

class Program
{
    static void Main(string[] args)
    {
        Biblioteca minhaBiblioteca = new Biblioteca();
        minhaBiblioteca.AdicionarLivro("O Tesouro de Olinda");
        minhaBiblioteca.AdicionarLivro("1984");

        Console.WriteLine("Livros na biblioteca:");
        foreach (string livro in minhaBiblioteca.Livros)
        {
            Console.WriteLine($"- {livro}");
        }
    }
}