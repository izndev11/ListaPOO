﻿using System;

public class Animal
{
    public string Nome { get; set; } = "Teiú";
    public int Idade { get; set; } = 3;

}

class Program1
{
    static void Main(string[] args)
    {
        Animal animal = new Animal();
        Console.WriteLine($"o nome do animal é {animal.Nome}");
        Console.WriteLine($"e ele está perambulando pelo mundo a {animal.Idade} anos");
    }
}