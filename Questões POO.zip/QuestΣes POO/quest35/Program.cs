﻿using System;

public class Conta
{
    public decimal Saldo { get; protected set; }

    public Conta(decimal saldoInicial)
    {
        Saldo = saldoInicial;
    }

    public void Depositar(decimal valor)
    {
        if (valor > 0)
        {
            Saldo += valor;
            Console.WriteLine($"Depósito de {valor:C} realizado. Saldo atual: {Saldo:C}");
        }
    }

    public virtual void Sacar(decimal valor)
    {
        if (valor > 0 && valor <= Saldo)
        {
            Saldo -= valor;
            Console.WriteLine($"Saque de {valor:C} realizado. Saldo atual: {Saldo:C}");
        }
        else
        {
            Console.WriteLine("Saldo insuficiente.");
        }
    }
}

// Classe derivada
public class ContaPoupanca : Conta
{
    public ContaPoupanca(decimal saldoInicial) : base(saldoInicial)
    {
    }

    public void RenderJuros()
    {
        decimal juros = Saldo * 0.01m;
        Saldo += juros;
        Console.WriteLine($"Juros de {juros:C} renderizados. Novo saldo: {Saldo:C}");
    }
}

public class Program35
{
    public static void Main(string[] args)
    {
        ContaPoupanca minhaPoupanca = new ContaPoupanca(1000.00m);

        minhaPoupanca.Depositar(500.00m);

        minhaPoupanca.RenderJuros();

        minhaPoupanca.Sacar(300.00m);
    }
}