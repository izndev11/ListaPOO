﻿using System;
using System.Collections.Generic;

public class Configuracao
{

    private Dictionary<string, string> configuracoes;

    public Configuracao()
    {
        configuracoes = new Dictionary<string, string>();
    }

    public void DefinirConfiguracao(string chave, string valor)
    {
        if (string.IsNullOrWhiteSpace(chave))
        {
            throw new ArgumentException("A chave não pode ser nula ou vazia.", nameof(chave));
        }
        if (valor == null)
        {
            throw new ArgumentNullException(nameof(valor), "O valor não pode ser nulo.");
        }

        configuracoes[chave] = valor;
        Console.WriteLine($"Configuração '{chave}' definida como '{valor}'.");
    }

    public string ObterConfiguracao(string chave)
    {
        if (string.IsNullOrWhiteSpace(chave))
        {
            throw new ArgumentException("A chave não pode ser nula ou vazia.", nameof(chave));
        }

        if (configuracoes.TryGetValue(chave, out string valor))
        {
            return valor;
        }
        else
        {
            Console.WriteLine($"A chave '{chave}' não foi encontrada nas configurações.");
            return null;
        }
    }

    public bool RemoverConfiguracao(string chave)
    {
        if (string.IsNullOrWhiteSpace(chave))
        {
            throw new ArgumentException("A chave não pode ser nula ou vazia.", nameof(chave));
        }

        bool removido = configuracoes.Remove(chave);
        if (removido)
        {
            Console.WriteLine($"Configuração '{chave}' removida.");
        }
        else
        {
            Console.WriteLine($"A chave '{chave}' não foi encontrada para remoção.");
        }
        return removido;
    }

    public void ExibirTodasConfiguracoes()
    {
        if (configuracoes.Count == 0)
        {
            Console.WriteLine("Nenhuma configuração definida.");
            return;
        }

        Console.WriteLine("\n--- Todas as Configurações ---");
        foreach (var kvp in configuracoes)
        {
            Console.WriteLine($"  {kvp.Key}: {kvp.Value}");
        }
        Console.WriteLine("-----------------------------\n");
    }
}

public class Program
{
    public static void Main(string[] args)
    {

        Configuracao appConfig = new Configuracao();

        appConfig.DefinirConfiguracao("Tema", "Escuro");
        appConfig.DefinirConfiguracao("FonteTamanho", "12");
        appConfig.DefinirConfiguracao("NotificacoesAtivas", "true");

        string tema = appConfig.ObterConfiguracao("Tema");
        Console.WriteLine($"Tema atual: {tema}");

        string tamanhoFonte = appConfig.ObterConfiguracao("FonteTamanho");
        Console.WriteLine($"Tamanho da Fonte: {tamanhoFonte}");

        string idioma = appConfig.ObterConfiguracao("Idioma");
        Console.WriteLine($"Idioma (se encontrado): {idioma}");

        appConfig.DefinirConfiguracao("Tema", "Claro");

        appConfig.ExibirTodasConfiguracoes();

        appConfig.RemoverConfiguracao("NotificacoesAtivas");

        appConfig.ExibirTodasConfiguracoes();
       
        appConfig.RemoverConfiguracao("Usuario");
    }
}