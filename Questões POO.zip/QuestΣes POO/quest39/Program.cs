﻿using System;
public class Jogo
{
    public string Nome { get; set; }

    public Jogo(string nome)
    {
        Nome = nome;
    }

    public void Iniciar()
    {
        Console.WriteLine($"Iniciando jogo: {Nome}");
    }
}

public class JogoOnline : Jogo
{
    public string EnderecoServidor { get; set; }

    public JogoOnline(string nome, string enderecoServidor) : base(nome)
    {
        EnderecoServidor = enderecoServidor;
    }

    public void Conectar()
    {
        Console.WriteLine($"Conectando ao servidor: {EnderecoServidor} para jogar {Nome}...");

    }
}

public class Program39
{
    public static void Main(string[] args)
    {
        Jogo jogoOffline = new Jogo("God of War Ragnarok");
        jogoOffline.Iniciar();

        JogoOnline jogoOnline = new JogoOnline("Valorant", "riotgames.com");
        jogoOnline.Iniciar();
        jogoOnline.Conectar();
    }
}