﻿using System;

public class Aluno
{
    public string Nome { get; set; } = string.Empty;
    public double Nota { get; set; }
}

class Program
{

    static void Main(string[] args)
    {

        Aluno aluno1 = new Aluno();
        Aluno aluno2 = new Aluno();

        aluno1.Nome = "Izânio";
        aluno1.Nota = 8.5;

        aluno2.Nome = "Gabriel";
        aluno2.Nota = 7.5;

        Console.WriteLine("--Informações do primeiro aluno--");
        Console.WriteLine($"Nome: {aluno1.Nome}");
        Console.WriteLine($"Aluno: {aluno1.Nota}");

        Console.WriteLine("--Informações do segundo aluno--");
        Console.WriteLine($"Nome: {aluno2.Nome}");
        Console.WriteLine($"Nota: {aluno2.Nota}");

    }
    
}