﻿using System;

public class Funcionario
{
    public string Nome { get; set; }
    public decimal SalarioBase { get; set; }

    public Funcionario(string nome, decimal salarioBase)
    {
        Nome = nome;
        SalarioBase = salarioBase;
    }

    public virtual decimal CalcularSalarioTotal()
    {
        return SalarioBase;
    }
}

public class Gerente : Funcionario
{
    public decimal Bonus { get; set; }

    public Gerente(string nome, decimal salarioBase, decimal bonus) : base(nome, salarioBase)
    {
        Bonus = bonus;
    }

    public override decimal CalcularSalarioTotal()
    {
        return SalarioBase + Bonus;
    }
}

public class Program36
{
    public static void Main(string[] args)
    {
        Funcionario func1 = new Funcionario("Izânio", 1518);
        Console.WriteLine($"Salário total de {func1.Nome}: {func1.CalcularSalarioTotal():C}");

        Gerente gerente1 = new Gerente("Elias", 3000, 800);
        Console.WriteLine($"Salário total de {gerente1.Nome} (Gerente): {gerente1.CalcularSalarioTotal():C}");
    }
}