﻿using System;

public class Produto
{
    private double _preco;

    public double Preco
    {
        get => _preco;
        private set
        {
            if (value < 0)
                throw new ArgumentException("Preço não pode ser negativo.");
            _preco = value;
        }
    }

    public Produto(double precoInicial)
    {
        if (precoInicial < 0)
            throw new ArgumentException("Preço inicial inválido.");
        Preco = precoInicial;
    }

    public void AplicarDesconto(double percentual)
    {
        if (percentual < 0 || percentual > 100)
            throw new ArgumentException("Percentual de desconto inválido. Deve ser entre 0 e 100.");

        double novoPreco = _preco * (1 - percentual / 100);

        if (novoPreco < 0)
            throw new InvalidOperationException("O desconto resultaria em um preço negativo.");

        Preco = novoPreco;
    }

    public Produto ComDesconto(double percentual)
    {
        if (percentual < 0 || percentual > 100)
            throw new ArgumentException("Percentual de desconto inválido.");

        double novoPreco = _preco * (1 - percentual / 100);
        if (novoPreco < 0)
            throw new InvalidOperationException("O desconto resultaria em um preço negativo.");

        return new Produto(novoPreco);
    }

    public void ExibirPreco()
    {
        Console.WriteLine($"O preço do produto é: {Preco:C}");
    }
}

class Program
{
    static void Main(string[] args)
    {
        try
        {
            Produto produto = new Produto(200.0);
            produto.ExibirPreco();

            produto.AplicarDesconto(20);
            produto.ExibirPreco();

            Produto produtoComDesconto = produto.ComDesconto(10);
            produtoComDesconto.ExibirPreco();

        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"Erro: {ex.Message}");
        }
        catch (InvalidOperationException ex)
        {
            Console.WriteLine($"Erro: {ex.Message}");
        }
    }
}
