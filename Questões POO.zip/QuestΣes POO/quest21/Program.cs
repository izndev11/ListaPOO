﻿using System;
public class Pessoa
{
    private int _idade;

    public int Idade
    {
        get { return _idade; }
        set { _idade = value; }
    }
}

class Program
{
    static void Main(string[] args) { }
}