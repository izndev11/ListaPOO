﻿using System;

public class Usuario
{
    public string Nome { get; set; }
    public string Email { get; private set; }

    public Usuario(string nome, string email)
    {
        Nome = nome;
        Email = email;
    }

    public void AlterarEmail(string novoEmail)
    {
        Email = novoEmail;
        Console.WriteLine($"Email: {Nome} => Atualizado para: {Email}");
    }
}

class Program
{
    static void Main(string[] args)
    {
        Usuario usuario = new Usuario("izanioluisdev@gmail.com", "izanioluisdev@gmail.com");
        Console.WriteLine($"Email atual: {usuario.Email}");
        usuario.AlterarEmail("izanioluis2007@email.com");
        Console.WriteLine($"Email após alteração: {usuario.Email}");
    }
}