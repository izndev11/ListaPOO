﻿using System;

public class Retangulo
{
    public double Largura { get; set; }
    public double Altura { get; set; }

    public Retangulo(double largura, double altura)
    {
        Largura = largura;
        Altura = altura;
    }

    public double Area()
    {
        return Largura * Altura;
    }
}

class Program
{
    static void Main(string[] args)
    {
        Retangulo meuRetangulo = new Retangulo(10.0, 5.0);

        double areaCalculada = meuRetangulo.Area();

        Console.WriteLine($"O retângulo tem largura {meuRetangulo.Largura} e altura {meuRetangulo.Altura}.");
        Console.WriteLine($"A área do retângulo é: {areaCalculada}");
    }
}