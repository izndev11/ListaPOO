﻿using System;

public abstract class Relatorio
{
    public string Titulo { get; set; }

    public Relatorio(string titulo)
    {
        Titulo = titulo;
    }

    public abstract string GerarConteudo();

    public void ExibirRelatorio()
    {
        Console.WriteLine($"--- Relatório: {Titulo} ---");
        Console.WriteLine(GerarConteudo());
        Console.WriteLine("------------------------------");
    }
}

public class RelatorioPDF : Relatorio
{
    public RelatorioPDF(string titulo) : base(titulo) { }

    public override string GerarConteudo()
    {
        return "Conteúdo em formato PDF: Dados formatados com fontes e layouts específicos.";
    }
}

public class RelatorioExcel : Relatorio
{
    public RelatorioExcel(string titulo) : base(titulo) { }

    public override string GerarConteudo()
    {
        return "Conteúdo em formato Excel: Dados em células, colunas e linhas, com fórmulas.";
    }
}

public class Program57
{
    public static void Main(string[] args)
    {
        List<Relatorio> relatorios = new List<Relatorio>();
        relatorios.Add(new RelatorioPDF("Vendas Mensais"));
        relatorios.Add(new RelatorioExcel("Despesas Trimestrais"));
        relatorios.Add(new RelatorioPDF("Inventário Atual"));

        Console.WriteLine("Gerando e exibindo relatórios:");
        foreach (Relatorio r in relatorios)
        {
            r.ExibirRelatorio();
        }
      
    }
}