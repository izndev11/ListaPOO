﻿using System;

public class Veiculo
{
    public string Marca { get; set; }
    public string Modelo { get; set; }

    public Veiculo(string marca, string modelo)
    {
        Marca = marca;
        Modelo = modelo;
    }

    public void Acelerar()
    {
        Console.WriteLine("Acelerando!");
    }
}

class Program
{
    static void Main(string[] args)
    {
        Veiculo meuCarro = new Veiculo("Honda", "Civic G10");

        Console.WriteLine($"Meu veículo é um {meuCarro.Marca} {meuCarro.Modelo}.");

        meuCarro.Acelerar();
    }
}