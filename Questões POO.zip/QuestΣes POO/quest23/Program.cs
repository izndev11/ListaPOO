﻿using System;

public class Aluno
{
    private double _nota;

    public double Nota
    {
        get => _nota;
        set
        {
            if (value < 0 || value > 10)
                throw new ArgumentOutOfRangeException("Nota deve estar entre 0 e 10.");
            _nota = value;
        }
    }

    public void ExibirNota()
    {
        Console.WriteLine($"A nota do aluno é: {_nota}");
    }
}

class Program
{
    static void Main(string[] args)
    {
        Aluno aluno = new Aluno();
        bool continuar = true;

        while (continuar)
        {
            try
            {
                Console.WriteLine("Digite a nota do aluno (de 0 a 10):");
                double nota = Convert.ToDouble(Console.ReadLine());

                aluno.Nota = nota;

              
                aluno.ExibirNota();

                Console.WriteLine("Deseja atribuir outra nota? (s/n)");
                string resposta = Console.ReadLine().ToLower();

                if (resposta != "s")
                {
                    continuar = false;
                }
            }
            catch (ArgumentOutOfRangeException e)
            {
                Console.WriteLine($"Erro: {e.Message}");
            }
            catch (FormatException)
            {
                Console.WriteLine("Erro: Por favor, insira um número válido.");
            }
        }

        Console.WriteLine("Obrigado por usar o sistema de notas!");
    }
}


