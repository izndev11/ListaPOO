﻿using System;
public abstract class Estrategia
{
    public abstract void Executar();
}

public class Ataque : Estrategia
{
    public override void Executar()
    {
        Console.WriteLine("Atacando o inimigo com força total!");

    }
}

public class Defesa : Estrategia
{
    public override void Executar()
    {
        Console.WriteLine("Fortificando a defesa para resistir.");
    }
}

public class Personagem
{
    public string Nome { get; set; }
    private Estrategia estrategiaAtual;

    public Personagem(string nome)
    {
        Nome = nome;
        estrategiaAtual = new Ataque();
    }

    public void DefinirEstrategia(Estrategia novaEstrategia)
    {
        estrategiaAtual = novaEstrategia;
        Console.WriteLine($"{Nome} mudou sua estratégia para: {novaEstrategia.GetType().Name}");
    }

    public void RealizarAcao()
    {
        Console.Write($"{Nome} decide ");
        estrategiaAtual.Executar();
    }
}
public class Program56
{
    public static void Main(string[] args)
    {
        Personagem guerreiro = new Personagem("Guerreiro");
        guerreiro.RealizarAcao();

        guerreiro.DefinirEstrategia(new Defesa());
        guerreiro.RealizarAcao();

        Personagem mago = new Personagem("Mago");
        mago.DefinirEstrategia(new Ataque());
        mago.RealizarAcao();
    }
}