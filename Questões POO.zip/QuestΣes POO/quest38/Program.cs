﻿using System;

// Classe base: Transporte
public class Transporte
{
    public virtual void Mover()
    {
        Console.WriteLine("Transporte se movendo...");
    }
}

public class Aviao : Transporte
{
    public double Altitude { get; private set; }

    public Aviao()
    {
        Altitude = 0;
    }

    public override void Mover()
    {
        Decolar();
        Console.WriteLine("Avião voando...");
    }

    public void Decolar()
    {
        Altitude = 1000;
        Console.WriteLine($"Avião decolando. Altitude atual: {Altitude} m");
    }

    public void Pousar()
    {
        Console.WriteLine("Avião pousando...");
        Altitude = 0;
    }
}

public class Program38
{
    public static void Main(string[] args)
    {
        Transporte meioDeTransporte = new Transporte();
        meioDeTransporte.Mover();

        Aviao meuAviao = new Aviao();
        meuAviao.Mover();         
        meuAviao.Pousar();
    }
}