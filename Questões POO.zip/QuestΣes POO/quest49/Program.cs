﻿using System;

public class ContaBancaria
{
    public decimal Saldo { get; protected set; }

    public ContaBancaria(decimal saldoInicial)
    {
        if (saldoInicial < 0)
            throw new ArgumentException("O saldo inicial não pode ser negativo.");
        Saldo = saldoInicial;
    }

    public virtual void Depositar(decimal valor)
    {
        if (valor > 0)
        {
            Saldo += valor;
            Console.WriteLine($"Depósito de {valor:C} realizado. Saldo atual: {Saldo:C}");
        }
        else
        {
            Console.WriteLine("O valor do depósito deve ser positivo.");
        }
    }

    public virtual bool Sacar(decimal valor)
    {
        if (valor > 0 && valor <= Saldo)
        {
            Saldo -= valor;
            Console.WriteLine($"Saque de {valor:C} realizado. Saldo atual: {Saldo:C}");
            return true;
        }
        else if (valor <= 0)
        {
            Console.WriteLine("O valor do saque deve ser positivo.");
            return false;
        }
        else
        {
            Console.WriteLine("Saldo insuficiente.");
            return false;
        }
    }
}

public class ContaCorrente : ContaBancaria
{
    public decimal LimiteChequeEspecial { get; set; }

    public ContaCorrente(decimal saldoInicial, decimal limiteChequeEspecial) : base(saldoInicial)
    {
        LimiteChequeEspecial = limiteChequeEspecial;
    }

    public override bool Sacar(decimal valor)
    {
        if (valor > 0 && (Saldo + LimiteChequeEspecial) >= valor)
        {
            Saldo -= valor;
            Console.WriteLine($"Saque de {valor:C} realizado. Saldo atual: {Saldo:C}");
            if (Saldo < 0)
                Console.WriteLine($"   (Utilizando limite de cheque especial. Saldo restante no limite: {(LimiteChequeEspecial + Saldo):C})");
            return true;
        }
        else if (valor <= 0)
        {
            Console.WriteLine("O valor do saque deve ser positivo.");
            return false;
        }
        else
        {
            Console.WriteLine("Saldo e limite de cheque especial insuficientes.");
            return false;
        }
    }
}

public class ContaInvestimento : ContaBancaria
{
    public double TaxaRendimentoAnual { get; set; }

    public ContaInvestimento(decimal saldoInicial, double taxaRendimentoAnual) : base(saldoInicial)
    {
        TaxaRendimentoAnual = taxaRendimentoAnual;
    }

    public void RenderJuros()
    {
        decimal juros = Saldo * (decimal)TaxaRendimentoAnual;
        Saldo += juros;
        Console.WriteLine($"Juros de {juros:C} renderizados (Taxa: {TaxaRendimentoAnual * 100}%). Saldo atual: {Saldo:C}");
    }

}

public class Program49
{
    public static void Main(string[] args)
    {
        ContaCorrente cc = new ContaCorrente(1000.00m, 500.00m);
        cc.Depositar(200.00m);
        cc.Sacar(700.00m);
        cc.Sacar(900.00m);

        Console.WriteLine("\n---");

        ContaInvestimento ci = new ContaInvestimento(5000.00m, 0.08);
        ci.Depositar(1000.00m);
        ci.RenderJuros();
        ci.Sacar(2000.00m);
    }
}