﻿using System;

public class Triangulo
{
    public double Lado1 { get; set; }
    public double Lado2 { get; set; }
    public double Lado3 { get; set; }

    public Triangulo(double lado1, double lado2, double lado3)
    {
        Lado1 = lado1;
        Lado2 = lado2;
        Lado3 = lado3;
    }

    public double Perimetro()
    {
        return Lado1 + Lado2 + Lado3;
    }
}

class Program
{
    static void Main(string[] args)
    {
        Triangulo meuTriangulo = new Triangulo(5.0, 8.0, 6.0);

        double perimetro = meuTriangulo.Perimetro();

        Console.WriteLine($"Os lados do triângulo são: {meuTriangulo.Lado1}, {meuTriangulo.Lado2}, {meuTriangulo.Lado3}");
        Console.WriteLine($"O perímetro do triângulo é: {perimetro}");
    }
}