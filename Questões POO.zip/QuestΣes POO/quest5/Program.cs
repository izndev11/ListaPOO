﻿using System;

public class Quadrado
{
    public double Lado {  get; set; }

    public double Area()
    {
        return Lado * Lado;
    }
}

class Program
{

    static void Main(string[] args)
    {
        Quadrado quadrado = new Quadrado();

        quadrado.Lado = 5.0;

        double areaDoQuadrado = quadrado.Area();

        Console.WriteLine($"O lado esquerdo é  {quadrado.Lado}cm.");
        Console.WriteLine($"A área do quadrado é {areaDoQuadrado}cm.");
    }
}
    