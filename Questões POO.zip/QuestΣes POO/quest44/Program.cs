﻿using System;

public class Veiculo
{
    public virtual void Acelerar()
    {
        Console.WriteLine("Veículo acelerando...");
    }
}

public class Bicicleta : Veiculo
{
    public override void Acelerar()
    {
        Console.WriteLine("Ciclista pedalando para acelerar.");
    }
}

public class Moto : Veiculo
{
    public override void Acelerar()
    {
        Console.WriteLine("Piloto acelera o motor da moto.");
    }
}

public class Program44
{
    public static void Main(string[] args)
    {
        Veiculo minhaBicicleta = new Bicicleta();
        minhaBicicleta.Acelerar();
        Veiculo minhaMoto = new Moto();
        minhaMoto.Acelerar();
    }
}