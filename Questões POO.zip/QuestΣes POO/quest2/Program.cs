﻿using System;

public class Carro
{
    public string Cor { get; set; } = "Vermelho";

}

class Program
{
    static void Main(string[] args)
    {
        Carro meuCarro = new Carro();
        Console.WriteLine($"a cor do carro é: {meuCarro.Cor}");
    }
}