﻿using System;
using System.Collections.Generic;

public class Pessoa
{
    public string Nome { get; set; }
    public string Contato { get; set; }

    public Pessoa(string nome, string contato)
    {
        Nome = nome;
        Contato = contato;
    }

    public virtual void ExibirInformacoes()
    {
        Console.WriteLine($"Nome: {Nome}, Contato: {Contato}");
    }
}

public class Cliente : Pessoa
{
    public string IdCliente { get; set; }

    public Cliente(string nome, string contato, string idCliente) : base(nome, contato)
    {
        IdCliente = idCliente;
    }

    public void FazerPedido()
    {
        Console.WriteLine($"Cliente {Nome} (ID: {IdCliente}) está fazendo um pedido.");
    }

    public override void ExibirInformacoes()
    {
        base.ExibirInformacoes();
        Console.WriteLine($"ID Cliente: {IdCliente}");
    }
}

public class Fornecedor : Pessoa
{
    public string Cnpj { get; set; }

    public Fornecedor(string nome, string contato, string cnpj) : base(nome, contato)
    {
        Cnpj = cnpj;
    }

    public void EntregarProduto()
    {
        Console.WriteLine($"Fornecedor {Nome} (CNPJ: {Cnpj}) está entregando produtos.");
    }

    public override void ExibirInformacoes()
    {
        base.ExibirInformacoes();
        Console.WriteLine($"CNPJ: {Cnpj}");
    }
}

public class Program47
{
    public static void Main(string[] args)
    {
    
        List<Pessoa> pessoas = new List<Pessoa>();

        pessoas.Add(new Cliente("Izânio", "izanioluis2007@email.com", "CLI001"));
        pessoas.Add(new Fornecedor("Empresa X", "contato@empX.com", "11.222.333/0001-44"));
        pessoas.Add(new Cliente("JP", "Jpxgf@email.com", "CLI002"));
        pessoas.Add(new Fornecedor("Fornecedor X", "info@fornY.com", "99.888.777/0001-55"));

        Console.WriteLine("Processando pessoas:");
        foreach (Pessoa p in pessoas)
        {
            p.ExibirInformacoes();

            if (p is Cliente cliente)
            {
                cliente.FazerPedido();
            }
            else if (p is Fornecedor fornecedor)
            {
                fornecedor.EntregarProduto();
            }
            Console.WriteLine("---");
        }
        
    }
}