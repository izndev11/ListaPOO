﻿using System;

public class Carro
{
    private const int VELOCIDADE_MAXIMA = 200;
    private const int VELOCIDADE_MINIMA = 0;
    private int _velocidade;

    public int Velocidade
    {
        get => _velocidade;
        private set
        {
            if (value < VELOCIDADE_MINIMA)
                throw new InvalidOperationException("A velocidade não pode ser negativa.");
            if (value > VELOCIDADE_MAXIMA)
                throw new InvalidOperationException($"A velocidade não pode ultrapassar {VELOCIDADE_MAXIMA} km/h.");
            _velocidade = value;
        }
    }

    public void Acelerar(int incremento)
    {
        if (incremento <= 0)
            throw new ArgumentException("O incremento deve ser positivo.");

        Velocidade += incremento;
    }

    public void Desacelerar(int decremento)
    {
        if (decremento <= 0)
            throw new ArgumentException("O decremento deve ser positivo.");

        Velocidade -= decremento;
    }

    public void ExibirVelocidade()
    {
        Console.WriteLine($"A velocidade atual do carro é: {_velocidade} km/h");
    }
}

class Program
{
    static void Main(string[] args)
    {
        try
        {
            Carro carro = new Carro();

            carro.Acelerar(50);
            carro.ExibirVelocidade();

            carro.Acelerar(100);
            carro.ExibirVelocidade();

            carro.Acelerar(100);
            carro.ExibirVelocidade();

            carro.Desacelerar(30);
            carro.ExibirVelocidade();

            carro.Desacelerar(250);
            carro.ExibirVelocidade();

        }
        catch (Exception ex)
        {
            Console.WriteLine($"Erro: {ex.Message}");
        }
    }
}
