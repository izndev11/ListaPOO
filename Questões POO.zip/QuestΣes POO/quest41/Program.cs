﻿using System;
using System.Collections.Generic;

public class Animal
{
    public virtual void Comer()
    {
        Console.WriteLine("Animal comendo.");
    }
}

public class Mamifero : Animal
{
    public override void Comer()
    {
        Console.WriteLine("Mamífero mastigando.");
    }
}

public class Ave : Animal
{
    public override void Comer()
    {
        Console.WriteLine("Ave bicando.");
    }
}

public class Program41
{
    public static void Main(string[] args)
    {

        List<Animal> animais = new List<Animal>();

        animais.Add(new Mamifero());
        animais.Add(new Ave());
        animais.Add(new Mamifero());
        animais.Add(new Animal());

        Console.WriteLine("Alimentando os animais:");
        
        foreach (Animal animal in animais)
        {
            animal.Comer();
        }

    }
}