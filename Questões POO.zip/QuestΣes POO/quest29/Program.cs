﻿using System;

public class Empregado
{

    private decimal salario;

    public Empregado(decimal salarioInicial)
    {

        Salario = salarioInicial;
    }

    public decimal Salario
    {
        get { return salario; }
        private set
        {

            if (value < 0)
            {
                throw new ArgumentException("O salário não pode ser negativo.");
            }
            salario = value;
        }
    }

    public decimal CalcularBonus()
    {
 
        return salario * 0.10m;
    }


    public void ExibirInformacoes()
    {
        Console.WriteLine($"Salário: {Salario:C}");
        Console.WriteLine($"Bônus: {CalcularBonus():C}");
    }
}

public class Program
{
    public static void Main(string[] args)
    {
 
        Empregado izanio = new Empregado(1518.00m);

      
        decimal bonusDoIzanio = izanio.CalcularBonus();
        Console.WriteLine($"O bônus do Izânio é: {bonusDoIzanio:C}");


        izanio.ExibirInformacoes();
       
    }
}