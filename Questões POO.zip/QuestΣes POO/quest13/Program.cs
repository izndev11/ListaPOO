﻿using System;

public class Data
{
    public int Dia { get; set; }
    public int Mes { get; set; }
    public int Ano { get; set; }

    public Data(int dia, int mes, int ano)
    {
        Dia = dia;
        Mes = mes;
        Ano = ano;
    }

    public string Formatar()
    {
        return $"{Dia:D2}/{Mes:D2}/{Ano:D4}";
    }
}

class Program
{
    static void Main(string[] args)
    {
        Data minhaData = new Data(10, 04, 2007);

        string dataFormatada = minhaData.Formatar();

        Console.WriteLine($"A data formatada é: {dataFormatada}");
    }
}