﻿using System;

public class Empregado
{
    public string Nome { get; set; }

    public Empregado(string nome)
    {
        Nome = nome;
    }

    public virtual decimal CalcularSalario()
    {
        return 0;
    }
}

public class Horista : Empregado
{
    public int HorasTrabalhadas { get; set; }
    public decimal TaxaPorHora { get; set; }

    public Horista(string nome, int horasTrabalhadas, decimal taxaPorHora) : base(nome)
    {
        HorasTrabalhadas = horasTrabalhadas;
        TaxaPorHora = taxaPorHora;
    }

    public override decimal CalcularSalario()
    {
        return HorasTrabalhadas * TaxaPorHora;
    }
}

public class Assalariado : Empregado
{
    public decimal SalarioFixo { get; set; }

    public Assalariado(string nome, decimal salarioFixo) : base(nome)
    {
        SalarioFixo = salarioFixo;
    }

    public override decimal CalcularSalario()
    {
        return SalarioFixo;
    }
}

public class Program42
{
    public static void Main(string[] args)
    {
        Horista horista1 = new Horista("Pedro", 160, 15.50m);
        Console.WriteLine($"{horista1.Nome} (Horista) - Salário: {horista1.CalcularSalario():C}");

        Assalariado assalariado1 = new Assalariado("Izânio", 4000.00m);
        Console.WriteLine($"{assalariado1.Nome} (Assalariado) - Salário: {assalariado1.CalcularSalario():C}");
    }
}