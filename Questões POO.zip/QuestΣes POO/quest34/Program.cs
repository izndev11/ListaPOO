﻿using System;

public class Pessoa
{
    public string Nome { get; set; }
    public int Idade { get; set; }

    public Pessoa(string nome, int idade)
    {
        Nome = nome;
        Idade = idade;
    }

    public virtual void Apresentar()
    {
        Console.WriteLine($"Olá, meu nome é {Nome} e tenho {Idade} anos.");
    }
}

public class Aluno : Pessoa
{
    public double Nota { get; set; }

    public Aluno(string nome, int idade, double nota) : base(nome, idade)
    {
        Nota = nota;
    }


    public void Estudar()
    {
        Console.WriteLine($"{Nome} está estudando para a prova.");
    }

    public override void Apresentar()
    {
        base.Apresentar();
        Console.WriteLine($"Minha nota é {Nota}.");
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        Aluno meuAluno = new Aluno("Izânio", 18, 7.6);
        meuAluno.Apresentar();

        meuAluno.Estudar();
    }
}
