﻿using System;

public class Veiculo
{
    public decimal Velocidade { get; set; }

    public Veiculo(decimal velocidadeInicial)
    {
        Velocidade = velocidadeInicial;
    }

    public void Acelerar(decimal incremento)
    {
        Velocidade += incremento;
        Console.WriteLine($"Veículo acelerando. Velocidade atual: {Velocidade} km/h");
    }
}

public class Carro : Veiculo
{
    public Carro(decimal velocidadeInicial) : base(velocidadeInicial) 
    {
    }

    public void Buzinar()
    {
        Console.WriteLine("Bi biiiiiii!");
    }
}

public class Program32
{
    public static void Main(string[] args)
    {
        Carro meuCarro = new Carro(50);
        meuCarro.Acelerar(20);
        meuCarro.Buzinar();
    }
}