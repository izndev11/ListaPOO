﻿using System;
using System.Collections.Generic;

public class Conta
{
    private double _saldo;

    public double Saldo => _saldo;

    public void Depositar(double valor)
    {
        if (valor <= 0)
            throw new ArgumentException("Valor para depósito deve ser positivo.");
        _saldo += valor;
    }

    public void Sacar(double valor)
    {
        if (valor <= 0)
            throw new ArgumentException("Valor para saque deve ser positivo.");

        if (valor > _saldo)
            throw new InvalidOperationException("Saldo insuficiente.");

        _saldo -= valor;
    }
}

public class Banco
{
    private readonly Dictionary<int, Conta> _contas = new();

    public IReadOnlyDictionary<int, Conta> Contas => _contas;

    public void AdicionarConta(int id, Conta conta)
    {
        if (_contas.ContainsKey(id))
            throw new ArgumentException("Uma conta com este ID já existe.");

        _contas.Add(id, conta);
    }

    public void RemoverConta(int id)
    {
        if (!_contas.ContainsKey(id))
            throw new ArgumentException("Conta não encontrada.");

        _contas.Remove(id);
    }

    public Conta ObterConta(int id)
    {
        if (!_contas.TryGetValue(id, out var conta))
        {
            throw new ArgumentException("Conta não encontrada.");
        }
        return conta;
    }

    public void Depositar(int id, double valor)
    {
        var conta = ObterConta(id);
        conta.Depositar(valor);
    }

    public void Sacar(int id, double valor)
    {
        var conta = ObterConta(id);
        conta.Sacar(valor);
    }
}

class Program
{
    public static void Main(string[] args)
    {
    
        var meuBanco = new Banco();

        var conta1 = new Conta();
        var conta2 = new Conta();

        try
        {
            meuBanco.AdicionarConta(101, conta1);
            meuBanco.AdicionarConta(102, conta2);
            Console.WriteLine("Contas adicionadas com sucesso!");
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"Erro ao adicionar conta: {ex.Message}");
        }

        try
        {
            meuBanco.Depositar(101, 1000.0);
            meuBanco.Depositar(102, 500.0);
            Console.WriteLine("Depósitos realizados com sucesso!");
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"Erro no depósito: {ex.Message}");
        }

        try
        {
            meuBanco.Sacar(101, 200.0);
            meuBanco.Sacar(102, 600.0);
            Console.WriteLine("Saques realizados com sucesso!");
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"Erro no saque: {ex.Message}");
        }
        catch (InvalidOperationException ex)
        {
            Console.WriteLine($"Erro no saque: {ex.Message}");
        }

        Console.WriteLine("\n--- Saldos Atuais ---");
        try
        {
            var conta1Verificada = meuBanco.ObterConta(101);
            Console.WriteLine($"Saldo da Conta 101: {conta1Verificada.Saldo:C}");

            var conta2Verificada = meuBanco.ObterConta(102);
            Console.WriteLine($"Saldo da Conta 102: {conta2Verificada.Saldo:C}");
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"Erro ao obter saldo: {ex.Message}");
        }

        try
        {
            meuBanco.RemoverConta(101);
            Console.WriteLine("\nConta 101 removida com sucesso!");
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"Erro ao remover conta: {ex.Message}");
        }

        try
        {
            meuBanco.ObterConta(101);
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"Tentativa de acessar conta 101 após remoção: {ex.Message}");
        }
    }
}