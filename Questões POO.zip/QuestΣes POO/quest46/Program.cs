﻿using System;

public class Produto
{
    public string Nome { get; set; }
    public decimal PrecoBase { get; set; }

    public Produto(string nome, decimal precoBase)
    {
        Nome = nome;
        PrecoBase = precoBase;
    }

    public virtual decimal CalcularPreco()
    {
        return PrecoBase;
    }
}

public class ProdutoFisico : Produto
{
    public decimal CustoFrete { get; set; }

    public ProdutoFisico(string nome, decimal precoBase, decimal custoFrete) : base(nome, precoBase)
    {
        CustoFrete = custoFrete;
    }

    public override decimal CalcularPreco()
    {
        return PrecoBase + CustoFrete;
    }
}

public class ProdutoServico : Produto
{
    public decimal TaxaServico { get; set; }

    public ProdutoServico(string nome, decimal precoBase, decimal taxaServico) : base(nome, precoBase)
    {
        TaxaServico = taxaServico;
    }

    public override decimal CalcularPreco()
    {
        return PrecoBase + TaxaServico;
    }
}

public class Program46
{
    public static void Main(string[] args)
    {
        ProdutoFisico livro = new ProdutoFisico("O Hobbit", 45.00m, 5.00m);
        Console.WriteLine($"Preço total de {livro.Nome} (Físico): {livro.CalcularPreco():C}");

        ProdutoServico consultoria = new ProdutoServico("Consultoria TI", 1000.00m, 200.00m);
        Console.WriteLine($"Preço total de {consultoria.Nome} (Serviço): {consultoria.CalcularPreco():C}");
    }
}