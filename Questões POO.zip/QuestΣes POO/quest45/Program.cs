﻿using System;

public interface iNadador
{
    void Nadar();
}

public interface iCorredor
{
    void Correr();
}

public class Triatleta : iNadador, iCorredor
{
    public string Nome { get; set; }

    public Triatleta(string nome)
    {
        Nome = nome;
    }

    public void Nadar()
    {
        Console.WriteLine($"{Nome} está nadando.");
    }

    public void Correr()
    {
        Console.WriteLine($"{Nome} está correndo.");
    }

    public void Competir()
    {
        Console.WriteLine($"{Nome} está competindo em um triatlo!");
        Nadar();
        Correr(); 
    }
}

public class Program45
{
    public static void Main(string[] args)
    {
        Triatleta meuTriatleta = new Triatleta("Izn");
        meuTriatleta.Competir();
       
    }
}