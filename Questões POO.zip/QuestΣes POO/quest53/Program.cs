﻿using System;

public abstract class Pagamento
{
    public decimal Valor { get; protected set; }

    public Pagamento(decimal valor)
    {
        if (valor <= 0)
            throw new ArgumentException("O valor do pagamento deve ser positivo.");
        Valor = valor;
    }

    public abstract void Processar();
}

public class CartaCredito : Pagamento
{
    public string NumeroCartao { get; set; }
    public string DataExpiracao { get; set; }

    public CartaCredito(decimal valor, string numeroCartao, string dataExpiracao) : base(valor)
    {
        NumeroCartao = numeroCartao;
        DataExpiracao = dataExpiracao;
    }

    public override void Processar()
    {
        Console.WriteLine($"Processando pagamento de {Valor:C} com Cartão de Crédito (Número: {NumeroCartao}, Exp: {DataExpiracao})...");
    }
}

public class Boleto : Pagamento
{
    public string CodigoBarras { get; set; }
    public DateTime DataVencimento { get; set; }

    public Boleto(decimal valor, string codigoBarras, DateTime dataVencimento) : base(valor)
    {
        CodigoBarras = codigoBarras;
        DataVencimento = dataVencimento;
    }

    public override void Processar()
    {
        Console.WriteLine($"Processando pagamento de {Valor:C} via Boleto (Vencimento: {DataVencimento.ToShortDateString()}, Código: {CodigoBarras})...");
    }
}

public class Program53
{
    public static void Main(string[] args)
    {
        List<Pagamento> pagamentos = new List<Pagamento>();
        pagamentos.Add(new CartaCredito(150.50m, "1234-5678-9012-3456", "12/25"));
        pagamentos.Add(new Boleto(75.20m, "34191.75600 60010.123456 7 01234567890", DateTime.Now.AddDays(10)));
        pagamentos.Add(new CartaCredito(200.00m, "9876-5432-1098-7654", "08/26"));

        Console.WriteLine("Processando pagamentos:");
        foreach (Pagamento p in pagamentos)
        {
            p.Processar();
            Console.WriteLine("---");
        }
        
    }
}