﻿using System;

public class Circulo
{
    public double Raio { get; set; }

    public double Area()
    {
        return Math.PI * Raio * Raio;
    }

    public double Perimetro()
    {
        return 2 * Math.PI * Raio;
    }

}

class Program
{
    static void Main(string[] args)
    {
        Circulo circulo = new Circulo();

        circulo.Raio = 10.0;

        double areaDoCirculo = circulo.Area();
        double perimetroDoCirculo = circulo.Perimetro();

        Console.WriteLine($"O raio do circulo é {circulo.Raio}cm");
        Console.WriteLine($"A área do circulo é {areaDoCirculo}cm");
        Console.WriteLine($"O perímetro do circulo é {perimetroDoCirculo}cm");
    }
}