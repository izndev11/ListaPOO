﻿using System;

public abstract class FuncionarioComBonus
{
    public string Nome { get; set; }
    public decimal SalarioBase { get; set; }

    public FuncionarioComBonus(string nome, decimal salarioBase)
    {
        Nome = nome;
        SalarioBase = salarioBase;
    }

    public abstract decimal CalcularBonus();

    public virtual decimal CalcularSalarioTotal()
    {
        return SalarioBase + CalcularBonus();
    }
}

public class Vendedor : FuncionarioComBonus
{
    public decimal VendasMes { get; set; }
    private const decimal PERCENTUAL_BONUS_VENDAS = 0.05m;

    public Vendedor(string nome, decimal salarioBase, decimal vendasMes) : base(nome, salarioBase)
    {
        VendasMes = vendasMes;
    }

    public override decimal CalcularBonus()
    {
        return VendasMes * PERCENTUAL_BONUS_VENDAS;
    }
}

public class Engenheiro : FuncionarioComBonus
{
    public decimal BonusFixo { get; set; }

    public Engenheiro(string nome, decimal salarioBase, decimal bonusFixo) : base(nome, salarioBase)
    {
        BonusFixo = bonusFixo;
    }

    public override decimal CalcularBonus()
    {
        return BonusFixo;
    }
}

public class Program54
{
    public static void Main(string[] args)
    {
        List<FuncionarioComBonus> funcionarios = new List<FuncionarioComBonus>();
        funcionarios.Add(new Vendedor("Elias", 3000m, 20000m));
        funcionarios.Add(new Engenheiro("Izânio", 7000m, 1000m));
        funcionarios.Add(new Vendedor("Emylliu", 3200m, 25000m));

        Console.WriteLine("Resumo salarial dos funcionários:");
        foreach (FuncionarioComBonus f in funcionarios)
        {
            Console.WriteLine($"{f.Nome} - Salário Total: {f.CalcularSalarioTotal():C}");
        }

    }
}