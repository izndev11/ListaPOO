﻿using System;

public class Calculadora
{
    public Calculadora()
    {
     
    }

    public double Somar(double a, double b)
    {
        return a + b;
    }

    public double Subtrair(double a, double b)
    {
        return a - b;
    }

    public double Multiplicar(double a, double b)
    {
        return a * b;
    }

    public double Dividir(double a, double b)
    {
        if (b != 0)
        {
            return a / b;
        }
        else
        {
            Console.WriteLine("Erro: Divisão por zero não permitida.");
            return double.NaN;
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        Calculadora calc = new Calculadora();
        Console.WriteLine($"5 + 3 = {calc.Somar(5, 3)}");       
        Console.WriteLine($"10 - 4 = {calc.Subtrair(10, 4)}");   
        Console.WriteLine($"6 * 7 = {calc.Multiplicar(6, 7)}"); 
        Console.WriteLine($"15 / 3 = {calc.Dividir(15, 3)}");   
        Console.WriteLine($"10 / 0 = {calc.Dividir(10, 0)}"); 
    }
}