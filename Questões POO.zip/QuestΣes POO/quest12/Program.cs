﻿using System;

public class Funcionario
{
    public string Nome { get; set; }
    public double Salario { get; private set; }

    public Funcionario(string nome, double salario)
    {
        Nome = nome;
        Salario = salario;
    }

    public void AumentarSalario(double percentual)
    {

        if (percentual > 0 && percentual <= 100)
        {
            Salario += Salario * (percentual / 100);
            Console.WriteLine($"O salário de {Nome} foi aumentado em {percentual}%.");
        }
        else
        {
            Console.WriteLine("Porcentagem de aumento inválida.");
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        Funcionario funcionario1 = new Funcionario("Marcão", 7000.00);

        Console.WriteLine($"Salário inicial de {funcionario1.Nome}: {funcionario1.Salario:C}");

        funcionario1.AumentarSalario(10);

        Console.WriteLine($"Novo salário de {funcionario1.Nome}: {funcionario1.Salario:C}");
    }
}