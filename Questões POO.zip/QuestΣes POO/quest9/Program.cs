﻿using System;
using System.Reflection.Metadata;

public class Produto
{
    public string Nome { get; set; } = string.Empty;
    public double Preco { get; set; } 

    public double aplicarDesconto()
    {
        return Preco * 0.90;
    }
}

class Program
{
    static void Main(string[] args)
    {
        Produto produto = new Produto();
        produto.Preco = 1500.00;

        double precoFinal = produto.aplicarDesconto();

        Console.WriteLine($"o preço final do produto com desconto é {precoFinal} reais");


    }
}