﻿using System;

public abstract class Animal
{
    public abstract void Mover();
}

public class Peixe : Animal
{
    public override void Mover()
    {
        Console.WriteLine("Peixe nadando.");
    }
}

public class Passaro : Animal
{
    public override void Mover()
    {
        Console.WriteLine("Pássaro voando.");
    }
}

public class Program52
{
    public static void Main(string[] args)
    {
        List<Animal> animais = new List<Animal>();
        animais.Add(new Peixe());
        animais.Add(new Passaro());
        animais.Add(new Peixe());

        Console.WriteLine("Como os animais se movem:");
        foreach (Animal a in animais)
        {
            a.Mover();
        }
        
    }
}