﻿using System;

public abstract class ItemMenu
{
    public string Nome { get; set; }
    public decimal Preco { get; set; }

    public ItemMenu(string nome, decimal preco)
    {
        Nome = nome;
        Preco = preco;
    }

    public abstract void Preparar();

    public void Exibir()
    {
        Console.WriteLine($"Item: {Nome}, Preço: {Preco:C}");
    }
}

public class PratoPrincipal : ItemMenu
{
    public string IngredientesPrincipais { get; set; }

    public PratoPrincipal(string nome, decimal preco, string ingredientesPrincipais) : base(nome, preco)
    {
        IngredientesPrincipais = ingredientesPrincipais;
    }

    public override void Preparar()
    {
        Console.WriteLine($"Preparando o prato principal '{Nome}' com {IngredientesPrincipais}...");
    }
}

public class Sobremesa : ItemMenu
{
    public string Cobertura { get; set; }

    public Sobremesa(string nome, decimal preco, string cobertura) : base(nome, preco)
    {
        Cobertura = cobertura;
    }

    public override void Preparar()
    {
        Console.WriteLine($"Preparando a sobremesa '{Nome}' com cobertura de {Cobertura}...");
    }
}

public class Program58
{
    public static void Main(string[] args)
    {
        List<ItemMenu> menu = new List<ItemMenu>();
        menu.Add(new PratoPrincipal("Bife a Cavalo", 45.00m, "Carne e Ovo"));
        menu.Add(new Sobremesa("Pudim", 12.50m, "Caramelo"));
        menu.Add(new PratoPrincipal("Frango Grelhado", 38.00m, "Frango e Legumes"));
        menu.Add(new Sobremesa("Brigadeiro", 5.00m, "Chocolate"));

        Console.WriteLine("Preparando itens do menu:");
        foreach (ItemMenu item in menu)
        {
            item.Exibir();
            item.Preparar();
            Console.WriteLine("---");
        }
        
    }
}