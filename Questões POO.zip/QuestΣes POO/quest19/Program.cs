﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Agenda
{
    public List<string> Contatos { get; private set; }

    public Agenda(List<string> contatosIniciais)
    {
        Contatos = contatosIniciais ?? new List<string>();
    }

    public string BuscarContato(string nome)
    {

        string contatoEncontrado = Contatos.FirstOrDefault(c => c.StartsWith(nome, StringComparison.OrdinalIgnoreCase));

        return contatoEncontrado ?? "Contato não encontrado.";
    }
}

class Program
{
    static void Main(string[] args)
    {
        List<string> contatos = new List<string> { "Izânio", "Elias"};
        Agenda minhaAgenda = new Agenda(contatos);

        Console.WriteLine($"Buscando por 'Izânio': {minhaAgenda.BuscarContato("Izânio")}"); 
        Console.WriteLine($"Buscando por 'Elias': {minhaAgenda.BuscarContato("Elias")}");    
        Console.WriteLine($"Buscando por 'Gabriel': {minhaAgenda.BuscarContato("Gabriel")}"); 
    }
}