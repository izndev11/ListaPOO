﻿using System;

public abstract class Veiculo
{
    public string Modelo { get; set; }

    public Veiculo(string modelo)
    {
        Modelo = modelo;
    }

    public abstract string ObterTipoCombustivel();

    public abstract void Viajar(double distancia);

    public virtual void Ligar()
    {
        Console.WriteLine($"{Modelo} ligando...");
    }
}

public class CarroEletrico : Veiculo
{
    public double Autonomia { get; set; }

    public CarroEletrico(string modelo, double autonomia) : base(modelo)
    {
        Autonomia = autonomia;
    }

    public override string ObterTipoCombustivel()
    {
        return "Eletricidade";
    }

    public override void Viajar(double distancia)
    {
        if (distancia <= Autonomia)
        {
            Console.WriteLine($"{Modelo} ({ObterTipoCombustivel()}) viajando {distancia} km.");
            Autonomia -= distancia;
        }
        else
        {
            Console.WriteLine($"{Modelo} ({ObterTipoCombustivel()}) não tem autonomia suficiente para viajar {distancia} km.");
        }
    }

    public void Recarregar()
    {
        Console.WriteLine($"{Modelo} recarregando bateria...");
        Autonomia = 400;
    }
}

public class CarroGasolina : Veiculo
{
    public double TanqueLitros { get; set; }
    public double ConsumoPorKm { get; set; }
    private double nivelCombustivelAtual;

    public CarroGasolina(string modelo, double tanqueLitros, double consumoPorKm, double nivelInicial) : base(modelo)
    {
        TanqueLitros = tanqueLitros;
        ConsumoPorKm = consumoPorKm;
        nivelCombustivelAtual = Math.Min(nivelInicial, tanqueLitros);
    }

    public override string ObterTipoCombustivel()
    {
        return "Gasolina";
    }

    public override void Viajar(double distancia)
    {
        double litrosNecessarios = distancia * ConsumoPorKm;
        if (litrosNecessarios <= nivelCombustivelAtual)
        {
            Console.WriteLine($"{Modelo} ({ObterTipoCombustivel()}) viajando {distancia} km.");
            nivelCombustivelAtual -= litrosNecessarios;
        }
        else
        {
            Console.WriteLine($"{Modelo} ({ObterTipoCombustivel()}) não tem combustível suficiente para viajar {distancia} km.");
        }
    }

    public void Abastecer(double litros)
    {
        Console.WriteLine($"Abastecendo {litros} litros em {Modelo}...");
        nivelCombustivelAtual += litros;
        if (nivelCombustivelAtual > TanqueLitros)
        {
            nivelCombustivelAtual = TanqueLitros;
        }
        Console.WriteLine($"Nível de combustível atual: {nivelCombustivelAtual:F2} L");
    }
}

public class Program55
{
    public static void Main(string[] args)
    {
        List<Veiculo> garagem = new List<Veiculo>();
        garagem.Add(new CarroEletrico("Tesla Model 3", 400));
        garagem.Add(new CarroGasolina("Gol", 50, 0.08, 40));
        Console.WriteLine("Simulação de viagens:");
        foreach (Veiculo v in garagem)
        {
            v.Ligar();
            if (v is CarroEletrico eletrico)
            {
                eletrico.Viajar(350);
                eletrico.Recarregar();
            }
            else if (v is CarroGasolina gasolina)
            {
                gasolina.Viajar(200);
                gasolina.Abastecer(15);
                gasolina.Viajar(300);
            }
            Console.WriteLine("---");
        }
      
    }
}