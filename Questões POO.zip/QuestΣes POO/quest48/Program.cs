﻿using System;

public abstract class Arquivo
{
    public string Nome { get; set; }
    public long Tamanho { get; protected set; }

    public Arquivo(string nome, long tamanho)
    {
        if (string.IsNullOrWhiteSpace(nome))
            throw new ArgumentException("O nome do arquivo não pode ser vazio.", nameof(nome));
        if (tamanho < 0)
            throw new ArgumentException("O tamanho do arquivo não pode ser negativo.", nameof(tamanho));

        Nome = nome;
        Tamanho = tamanho;
    }

    public abstract void Salvar();

    public virtual void ExibirDetalhes()
    {
        Console.WriteLine($"Arquivo: {Nome}, Tamanho: {Tamanho} bytes");
    }
}

public class ArquivoTexto : Arquivo
{
    public string Conteudo { get; set; }

    public ArquivoTexto(string nome, string conteudo) : base(nome, System.Text.Encoding.UTF8.GetByteCount(conteudo))
    {
        Conteudo = conteudo;
    }

    public override void Salvar()
    {
        Console.WriteLine($"Salvando arquivo de texto '{Nome}' ({Tamanho} bytes)...");
    }
}

public class ArquivoBinario : Arquivo
{
    public byte[] Dados { get; set; }

    public ArquivoBinario(string nome, byte[] dados) : base(nome, dados.Length)
    {
        Dados = dados;
    }

    public override void Salvar()
    {
        Console.WriteLine($"Salvando arquivo binário '{Nome}' ({Tamanho} bytes)...");

    }
}

public class Program48
{
    public static void Main(string[] args)
    {
        try
        {
            ArquivoTexto log = new ArquivoTexto("log.txt", "Este é um log de atividades.");
            log.ExibirDetalhes();
            log.Salvar();

            byte[] dadosImagem = { 0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10 };
            ArquivoBinario imagem = new ArquivoBinario("foto.jpg", dadosImagem);
            imagem.ExibirDetalhes();
            imagem.Salvar();

        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"Erro: {ex.Message}");
        }
    
    }
}