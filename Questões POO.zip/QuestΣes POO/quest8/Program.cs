﻿using System;

public class ContaBancaria
{
    public double Saldo { get; set; }

    public ContaBancaria(double saldoInicial)
    {
        Saldo = saldoInicial;
    }
    public void Depositar(double valor)
    {
        if (valor > 0)
        {
            Saldo += valor;
            Console.WriteLine($"Depósito de {valor:C} feito.");
        }
        else 
        { 
            Console.WriteLine("o valor do depósito deve ser positivo.");
        }

    }

}

class Program
{
    static void Main(string[] args)
    {
        ContaBancaria contaBancaria = new ContaBancaria(100.0);

        Console.WriteLine($"Saldo Inicial: {contaBancaria.Saldo:C}");

        contaBancaria.Depositar(50.0);

        Console.WriteLine($"Saldo atualizado: {contaBancaria.Saldo:C}");
    }
}