﻿using System;

public class Conta
{
    private double _saldo;

    public double Saldo => _saldo;

    public void Depositar(double valor)
    {
        if (valor <= 0)
            throw new ArgumentException("Valor para depósito deve ser positivo.");
        _saldo += valor;
    }

    public void Sacar(double valor)
    {
        if (valor <= 0)
            throw new ArgumentException("Valor para saque deve ser positivo.");

        if (valor > _saldo)
            throw new InvalidOperationException("Saldo insuficiente.");

        _saldo -= valor;
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        Conta minhaConta = new Conta();

        try
        {
            Console.WriteLine("Depositando R$ 100,00...");
            minhaConta.Depositar(100.00);
            Console.WriteLine($"Saldo atual: R$ {minhaConta.Saldo:F2}");

            Console.WriteLine("\nSacando R$ 50,00...");
            minhaConta.Sacar(50.00);
            Console.WriteLine($"Saldo atual: R$ {minhaConta.Saldo:F2}");

            Console.WriteLine("\nTentando sacar R$ 70,00 (saldo insuficiente)...");
            minhaConta.Sacar(70.00);
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"Erro de argumento: {ex.Message}");
        }
        catch (InvalidOperationException ex)
        {
            Console.WriteLine($"Erro de operação: {ex.Message}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ocorreu um erro inesperado: {ex.Message}");
        }

        Console.WriteLine("\nOperações concluídas.");
        Console.ReadKey();
    }
}
