﻿using System;

public class Forma
{

    public virtual double CalcularArea()
    {
        return 0.0;
    }
}

public class Quadrado : Forma
{
    public double Lado { get; set; }

    public Quadrado(double lado)
    {
        Lado = lado;
    }

    public override double CalcularArea()
    {
        return Lado * Lado;
    }
}

public class Program33
{
    public static void Main(string[] args)
    {
        Quadrado meuQuadrado = new Quadrado(4.0);
        double area = meuQuadrado.CalcularArea();
        Console.WriteLine($"A área do quadrado é: {area}");
    }
}